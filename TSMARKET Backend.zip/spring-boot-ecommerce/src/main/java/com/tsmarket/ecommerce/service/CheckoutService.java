package com.tsmarket.ecommerce.service;

import com.tsmarket.ecommerce.dto.Purchase;
import com.tsmarket.ecommerce.dto.PurchaseResponse;

public interface CheckoutService {

    PurchaseResponse placeOrder(Purchase purchase);
}
